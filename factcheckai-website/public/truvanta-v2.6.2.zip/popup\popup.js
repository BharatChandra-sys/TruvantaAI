// Copyright 2027 Bodapati Bharat Chandra. All rights reserved.
// Licensed under the Apache License, Version 2.0
// SPDX-License-Identifier: Apache-2.0
// Project: TruvantaAI � https://github.com/BharatChandra-sys/fake-news-extension
// API is defined in config.js (loaded before this script)

let token = null;
let user = null;
let currentSessionId = null;
let history = [];
let sessions = [];

const chatContainer = document.getElementById("chat-container");
const inputText     = document.getElementById("input-text");
const sendBtn       = document.getElementById("send-btn");

// ── Wire buttons ──────────────────────────────────────────────
document.getElementById("open-sidebar-btn").addEventListener("click", openSidebar);
document.getElementById("close-sidebar-btn").addEventListener("click", closeSidebar);
document.getElementById("sidebar-overlay").addEventListener("click", closeSidebar);
document.getElementById("new-chat-btn").addEventListener("click", newChat);
document.getElementById("new-chat-sidebar-btn").addEventListener("click", newChat);
document.getElementById("logout-btn").addEventListener("click", doLogout);
sendBtn.addEventListener("click", send);
inputText.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
});
inputText.addEventListener("input", autoResize);

// Sidebar nav — use chrome.runtime.getURL for Kiwi compatibility
document.getElementById("nav-dashboard").addEventListener("click", () => { window.location.href = chrome.runtime.getURL("popup/dashboard.html"); });
document.getElementById("nav-saved").addEventListener("click",     () => { window.location.href = chrome.runtime.getURL("popup/saved.html"); });
document.getElementById("nav-history").addEventListener("click",   () => { window.location.href = chrome.runtime.getURL("popup/history.html"); });
document.getElementById("nav-settings").addEventListener("click",  () => { window.location.href = chrome.runtime.getURL("popup/settings.html"); });

// ── Init ──────────────────────────────────────────────────────
// Show spinner immediately — before any async work
chatContainer.innerHTML = `
  <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:12px;opacity:0.5">
    <div class="spin-ring"></div>
    <span style="font-size:12px;color:var(--t3)">Loading…</span>
  </div>`;

chrome.storage.local.get(["token", "user", "currentSessionId"], async d => {
  if (!d.token) { window.location.href = chrome.runtime.getURL("popup/login.html"); return; }
  token = d.token;
  user  = d.user;
  currentSessionId = d.currentSessionId || null;
  updateUserUI();
  
  // Initialize voice button after DOM is ready
  initVoiceButton();
  
  await loadSessions();
  if (currentSessionId) {
    await loadSessionMessages(currentSessionId);
  } else {
    showWelcome();
  }
  // Small delay to ensure storage write from service worker is complete
  setTimeout(() => {
    chrome.storage.local.get(["selectedText", "pendingAnalysis"], sd => {
      if (sd.selectedText && sd.pendingAnalysis) {
        chrome.storage.local.remove(["selectedText", "pendingAnalysis"]);
        inputText.value = sd.selectedText;
        autoResize();
        send();
      }
    });
  }, 150);
});

chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === "ANALYZE_TEXT") { inputText.value = msg.text; send(); }
});

// ── User UI ───────────────────────────────────────────────────
function updateUserUI() {
  if (!user) return;
  const initials = (user.name || user.email || "?").charAt(0).toUpperCase();
  const avatarEl = document.getElementById("sidebar-avatar");
  if (avatarEl) {
    if (user.picture) {
      avatarEl.innerHTML = `<img src="${user.picture}" alt="">`;
    } else {
      avatarEl.textContent = initials;
    }
  }
  const nameEl  = document.getElementById("sidebar-name");
  const emailEl = document.getElementById("sidebar-email");
  if (nameEl)  nameEl.textContent  = user.name  || "User";
  if (emailEl) emailEl.textContent = user.email || "";
}

function doLogout() {
  chrome.storage.local.clear(() => { window.location.href = chrome.runtime.getURL("popup/login.html"); });
}

// ── Sidebar ───────────────────────────────────────────────────
function openSidebar() {
  document.getElementById("sidebar").style.transform = "translateX(0)";
  document.getElementById("sidebar-overlay").classList.add("visible");
}
function closeSidebar() {
  document.getElementById("sidebar").style.transform = "";
  document.getElementById("sidebar-overlay").classList.remove("visible");
}

// ── Sessions ──────────────────────────────────────────────────
async function loadSessions() {
  try {
    const res = await authFetch("/history/sessions");
    if (!res.ok) return;
    const data = await readJsonSafe(res) || {};
    // Handle both paginated {sessions, total} and legacy array response
    sessions = Array.isArray(data) ? data : (data.sessions || []);
    renderSessions();
  } catch(_) {}
}

function renderSessions() {
  const list = document.getElementById("sessions-list");
  if (!list) return;
  list.innerHTML = "";
  if (!sessions.length) {
    const p = document.createElement("p");
    p.style.cssText = "font-size:11px;color:var(--t3);padding:8px 10px;";
    p.textContent = "No chats yet";
    list.appendChild(p);
    return;
  }
  sessions.forEach(s => {
    const div = document.createElement("div");
    div.className = "session-item" + (s.id === currentSessionId ? " active" : "");
    div.innerHTML = `
      <span class="material-symbols-outlined ms-14" style="color:var(--t3);flex-shrink:0">chat_bubble</span>
      <span class="s-title">${esc(s.title)}</span>
      <button class="session-del"><span class="material-symbols-outlined ms-12">delete</span></button>`;
    div.addEventListener("click", () => switchSession(s.id));
    div.querySelector(".session-del").addEventListener("click", e => {
      e.stopPropagation(); deleteSession(s.id);
    });
    list.appendChild(div);
  });
}

async function switchSession(id) {
  currentSessionId = id;
  chrome.storage.local.set({ currentSessionId: id });
  closeSidebar();
  const s = sessions.find(x => x.id === id);
  if (s) setChatTitle(s.title);
  chatContainer.innerHTML = "";
  await loadSessionMessages(id);
  renderSessions();
}

async function loadSessionMessages(sessionId) {
  console.log(`[TruvantaAI] Loading session messages for ID: ${sessionId}`);
  // Show skeleton while loading
  chatContainer.innerHTML = `
    <div class="skeleton-wrap">
      <div class="skeleton-line" style="width:60%"></div>
      <div class="skeleton-line" style="width:85%"></div>
      <div class="skeleton-line" style="width:45%"></div>
    </div>
    <div class="skeleton-wrap" style="align-items:flex-end">
      <div class="skeleton-line" style="width:50%"></div>
    </div>
    <div class="skeleton-wrap">
      <div class="skeleton-line" style="width:75%"></div>
      <div class="skeleton-line" style="width:90%"></div>
    </div>`;
  try {
    const res = await authFetch(`/history/sessions/${sessionId}/messages`);
    console.log(`[TruvantaAI] Session messages response:`, res.status, res.ok);
    if (!res.ok) { 
      console.error(`[TruvantaAI] Failed to load session messages: ${res.status}`);
      showWelcome(); 
      return; 
    }
    const msgs = await readJsonSafe(res) || [];
    console.log(`[TruvantaAI] Loaded ${msgs.length} messages`);
    if (!msgs.length) { 
      console.warn(`[TruvantaAI] Session has no messages, showing welcome`);
      showWelcome(); 
      return; 
    }
    chatContainer.innerHTML = "";
    history = [];
    msgs.forEach(m => {
      if (m.role === "user") {
        addUserMsg(m.content, false);
        history.push({ role: "user", content: m.content });
      } else {
        if (m.is_claim) {
          addFactCard(m, false, false);
        } else {
          addChatReply(m.content, false, false);
          history.push({ role: "assistant", content: m.content });
        }
      }
    });
    scrollBottom();
    console.log(`[TruvantaAI] Session loaded successfully with ${history.length} history items`);
  } catch(e) { 
    console.error(`[TruvantaAI] Error loading session:`, e);
    showWelcome(); 
  }
}

async function newChat() {
  currentSessionId = null;
  history = [];
  chrome.storage.local.remove("currentSessionId");
  setChatTitle("TruvantaAI");
  chatContainer.innerHTML = "";
  showWelcome();
  closeSidebar();
}

async function deleteSession(id) {
  try {
    await authFetch(`/history/sessions/${id}`, { method: "DELETE" });
    sessions = sessions.filter(s => s.id !== id);
    if (currentSessionId === id) newChat();
    renderSessions();
  } catch(_) {}
}

// ── Chat UI ───────────────────────────────────────────────────
function showWelcome() {
  const wrap = document.createElement("div");
  wrap.className = "welcome-screen";
  wrap.innerHTML = `
    <img src="../icons/logo.png" alt="" class="welcome-logo-img" style="width:56px;height:56px;object-fit:contain;margin-bottom:4px;">
    <div class="welcome-brand"><span class="brand-main">Truvanta</span><span class="brand-ai">AI</span></div>
    <div class="welcome-sub">Ask me anything or paste a news claim.<br>I'll chat or fact-check automatically.</div>
    <div class="welcome-chips">
      <button class="welcome-chip" id="wc1">📰 Paste a headline to fact-check</button>
      <button class="welcome-chip" id="wc2">💬 Ask me anything</button>
      <button class="welcome-chip welcome-chip-page" id="wc3">🌐 Analyze this page</button>
    </div>`;
  chatContainer.innerHTML = "";
  chatContainer.appendChild(wrap);
  document.getElementById("wc1").addEventListener("click", () => setInput("Is this news real? [paste headline]"));
  document.getElementById("wc2").addEventListener("click", () => setInput("What is misinformation?"));
  document.getElementById("wc3").addEventListener("click", analyzeCurrentPage);
}

function setInput(text) {
  inputText.value = text;
  inputText.focus();
  autoResize();
}

async function analyzeCurrentPage() {
  // Get the active tab and extract its text via content script
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      addChatReply("Couldn't access the current tab. Try pasting the text manually.");
      return;
    }
    // Inject a one-shot script to grab visible text
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        // Grab main article text, fallback to body
        const article = document.querySelector("article, main, [role='main']");
        const el = article || document.body;
        return el.innerText.replace(/\s+/g, " ").trim().slice(0, 1200);
      }
    });
    const pageText = results?.[0]?.result;
    if (!pageText || pageText.length < 30) {
      addChatReply("Couldn't extract enough text from this page. Try pasting the claim manually.");
      return;
    }
    inputText.value = pageText;
    autoResize();
    send();
  } catch (err) {
    addChatReply("Page analysis isn't available here. Try on a news article page.");
  }
}

const escapeHtml = s => String(s)
  .replace(/&/g, "&amp;")
  .replace(/</g, "&lt;")
  .replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;")
  .replace(/'/g, "&#39;");
const esc = escapeHtml;
const scrollBottom = () => { chatContainer.scrollTop = chatContainer.scrollHeight; };

// ── Source credibility ────────────────────────────────────────
const HIGH_CRED_DOMAINS = new Set([
  "reuters.com","apnews.com","bbc.com","bbc.co.uk","npr.org",
  "theguardian.com","nytimes.com","washingtonpost.com","wsj.com",
  "bloomberg.com","ft.com","economist.com","nature.com","science.org",
  "who.int","cdc.gov","nih.gov","gov.uk","europa.eu","un.org",
  "snopes.com","Truvanta.org","politifact.com","fullfact.org",
  "aljazeera.com","dw.com","france24.com","abc.net.au","cbc.ca"
]);

function getCredTag(url) {
  try {
    const host = new URL(url).hostname.replace(/^www\./, "");
    if (HIGH_CRED_DOMAINS.has(host)) return { label: "HIGH", cls: "cred-high" };
    return { label: "MED", cls: "cred-med" };
  } catch { return { label: "MED", cls: "cred-med" }; }
}

function addUserMsg(text, scroll = true, imageUrl = null) {
  const el = document.createElement("div");
  el.className = "user-bubble";
  if (imageUrl) {
    const img = document.createElement("img");
    img.src = imageUrl;
    img.style.cssText = "max-width:100%;max-height:160px;border-radius:8px;display:block;margin-bottom:6px;object-fit:cover";
    img.alt = "attached image";
    el.appendChild(img);
  }
  const textNode = document.createElement("span");
  textNode.textContent = text || (imageUrl ? "Image attached" : "");
  el.appendChild(textNode);
  chatContainer.appendChild(el);
  if (scroll) scrollBottom();
}

function addTyping() {
  const row = document.createElement("div");
  row.className = "bot-row";
  row.innerHTML = `
    <div class="bot-avatar"><span class="material-symbols-outlined">fact_check</span></div>
    <div class="bot-bubble typing-status">
      <span class="typing-step" id="ts1">Analyzing claim...</span>
      <span class="typing-step" id="ts2">Checking sources...</span>
      <span class="typing-step" id="ts3">Computing verdict...</span>
    </div>`;
  chatContainer.appendChild(row);
  scrollBottom();

  // Show only one step at a time, cycling
  const steps = row.querySelectorAll(".typing-step");
  let step = 0;
  steps[0].classList.add("active");

  const timer = setInterval(() => {
    steps[step].classList.remove("active");
    step = (step + 1) % steps.length;
    steps[step].classList.add("active");
  }, 1400);

  row._clearTimer = () => clearInterval(timer);
  const origRemove = row.remove.bind(row);
  row.remove = () => { row._clearTimer(); origRemove(); };
  return row;
}

function addChatReply(text, scroll = true, animate = true) {
  const row = document.createElement("div");
  row.className = "bot-row";
  const avatar = document.createElement("div");
  avatar.className = "bot-avatar";
  avatar.innerHTML = `<span class="material-symbols-outlined">smart_toy</span>`;
  const bubble = document.createElement("div");
  bubble.className = "bot-bubble";
  row.appendChild(avatar);
  row.appendChild(bubble);
  chatContainer.appendChild(row);

  if (!animate) {
    bubble.innerHTML = renderMarkdown(text);
    if (scroll) scrollBottom();
    return;
  }

  // Word-by-word typewriter then render markdown at end
  const words = text.split(" ");
  let i = 0;
  const tw = setInterval(() => {
    i++;
    bubble.textContent = words.slice(0, i).join(" ");
    if (i >= words.length) {
      clearInterval(tw);
      bubble.innerHTML = renderMarkdown(text);
    }
    if (scroll) scrollBottom();
  }, 35);
}

function renderMarkdown(text) {
  const safe = escapeHtml(text || "");
  return safe
    // Bold **text**
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    // Italic *text*
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    // Numbered list: "1. item" at start of line
    .replace(/^(\d+)\.\s+(.+)$/gm, "<li style='margin:4px 0;list-style:decimal;margin-left:18px'>$2</li>")
    // Bullet list: "- item" or "• item"
    .replace(/^[-•]\s+(.+)$/gm, "<li style='margin:4px 0;list-style:disc;margin-left:18px'>$1</li>")
    // Wrap consecutive <li> in <ol> or <ul>
    .replace(/(<li[^>]*>.*<\/li>\n?)+/g, m => `<ul style="margin:6px 0;padding:0">${m}</ul>`)
    // Line breaks
    .replace(/\n/g, "<br>");
}

function ensureArray(value) {
  return Array.isArray(value) ? value : [];
}

function normalizeMessageResponse(data) {
  const normalized = data && typeof data === "object" ? { ...data } : {};
  normalized.evidence_articles = ensureArray(normalized.evidence_articles);
  normalized.evidence = ensureArray(normalized.evidence);
  normalized.highlights = ensureArray(normalized.highlights);
  normalized.manipulation_signals = ensureArray(normalized.manipulation_signals);
  normalized.sub_claims = ensureArray(normalized.sub_claims);
  if (!normalized.stance_summary || typeof normalized.stance_summary !== "object") {
    normalized.stance_summary = { support: 0, contradict: 0, neutral: 0 };
  }
  return normalized;
}

function feedbackClaimText(data) {
  return data.primary_claim || data.content || data.explanation || "";
}

function addFactCard(data, scroll = true, animate = true) {
  const verdict  = (data.verdict || "uncertain").toLowerCase();
  const confPct  = Math.round((data.confidence || 0) * 100);
  const mlPct    = Math.round((data.ml_score   || 0) * 100);
  const aiPct    = Math.round((data.ai_score   || 0) * 100);
  const newsPct  = data.evidence_score != null
    ? Math.round(data.evidence_score * 100)
    : (data.evidence_articles?.length || data.evidence?.length) ? 60 : 0;

  const srcCount = data.evidence_articles?.length || data.evidence?.length || 0;

  const vClass    = verdict === "real" ? "v-real" : verdict === "fake" ? "v-fake" : "v-uncertain";
  const vIcon     = verdict === "real" ? "check_circle" : verdict === "fake" ? "cancel" : "help";
  const vLabel    = verdict === "real" ? "REAL" : verdict === "fake" ? "FAKE" : "UNCERTAIN";
  const confColor = verdict === "real" ? "var(--real)" : verdict === "fake" ? "var(--fake)" : "var(--warn)";
  const mlFill    = mlPct > 50 ? "fill-fake" : "fill-real";
  const newsFill  = newsPct > 50 ? "fill-real" : "fill-fake";

  // ── Phase 2: Cooldown friction UX ─────────────────────────────
  const cooldown = data.cooldown || null;
  if (cooldown && cooldown.cooldown_level) {
    const level = cooldown.cooldown_level;
    
    if (level === "VIRAL_PANIC") {
      showViralPanicInterstitial(data, cooldown, () => {
        _renderFactCard(data, scroll, animate);
      });
      return;
    } else if (level === "HIGH_CONCERN") {
      showHighConcernFriction(data, cooldown, () => {
        _renderFactCard(data, scroll, animate);
      });
      return;
    } else if (level === "CAUTION") {
      showCautionBanner(data, cooldown);
    }
  }

  // Normal rendering (no friction or CAUTION level)
  _renderFactCard(data, scroll, animate);
}

// ── Friction UX Components (Phase 2.3) ────────────────────────

function showViralPanicInterstitial(data, cooldown, onComplete) {
  const overlay = document.createElement("div");
  overlay.className = "friction-overlay viral-panic";
  overlay.innerHTML = `
    <div class="friction-modal">
      <div class="friction-icon">
        <span class="material-symbols-outlined">warning</span>
      </div>
      <div class="friction-title">⚠️ VIRAL MISINFORMATION ALERT</div>
      <div class="friction-subtitle">This claim is spreading rapidly and shows high risk of being false</div>
      <div class="friction-stats">
        <div class="friction-stat">
          <span class="friction-stat-label">Fake Probability</span>
          <span class="friction-stat-value">${Math.round((cooldown.breakdown?.components?.fake_probability?.value || 0) * 100)}%</span>
        </div>
        <div class="friction-stat">
          <span class="friction-stat-label">Velocity Score</span>
          <span class="friction-stat-value">${Math.round((cooldown.breakdown?.components?.velocity?.value || 0) * 100)}%</span>
        </div>
        <div class="friction-stat">
          <span class="friction-stat-label">Cooldown Score</span>
          <span class="friction-stat-value">${Math.round((cooldown.cooldown_score || 0) * 100)}%</span>
        </div>
      </div>
      <div class="friction-message">
        Please take a moment to review the evidence before sharing this content.
        Viral misinformation can cause real harm.
      </div>
      <div class="friction-countdown">
        <div class="countdown-ring">
          <svg class="countdown-svg" viewBox="0 0 36 36">
            <path class="countdown-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
            <path class="countdown-progress" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
          </svg>
          <div class="countdown-number" id="friction-countdown">10</div>
        </div>
        <div class="countdown-label">seconds remaining</div>
      </div>
      <button class="friction-btn friction-btn-disabled" id="friction-continue" disabled>Continue to Analysis</button>
      <button class="friction-btn-link" id="friction-bypass">I understand the risks, skip this</button>
    </div>
  `;
  
  document.body.appendChild(overlay);
  
  let secondsLeft = cooldown.delay_seconds || 10;
  const countdownEl = document.getElementById("friction-countdown");
  const continueBtn = document.getElementById("friction-continue");
  const bypassBtn = document.getElementById("friction-bypass");
  const progressPath = overlay.querySelector(".countdown-progress");
  
  const timer = setInterval(() => {
    secondsLeft--;
    countdownEl.textContent = secondsLeft;
    
    const progress = ((cooldown.delay_seconds - secondsLeft) / cooldown.delay_seconds) * 100;
    progressPath.style.strokeDasharray = `${progress}, 100`;
    
    if (secondsLeft <= 0) {
      clearInterval(timer);
      continueBtn.disabled = false;
      continueBtn.classList.remove("friction-btn-disabled");
      continueBtn.classList.add("friction-btn-enabled");
    }
  }, 1000);
  
  continueBtn.addEventListener("click", () => {
    clearInterval(timer);
    trackFrictionEvent("viral_panic_completed", cooldown);
    overlay.remove();
    onComplete();
  });
  
  bypassBtn.addEventListener("click", () => {
    clearInterval(timer);
    trackFrictionEvent("viral_panic_bypassed", cooldown);
    overlay.remove();
    onComplete();
  });
}

function showHighConcernFriction(data, cooldown, onComplete) {
  const row = document.createElement("div");
  row.className = "bot-row";
  
  const avatar = document.createElement("div");
  avatar.className = "bot-avatar";
  avatar.innerHTML = `<span class="material-symbols-outlined">warning</span>`;
  
  const card = document.createElement("div");
  card.className = "friction-card high-concern";
  card.innerHTML = `
    <div class="friction-card-header">
      <span class="material-symbols-outlined friction-card-icon">report</span>
      <div class="friction-card-title">High-Risk Content Detected</div>
    </div>
    <div class="friction-card-body">
      <div class="friction-card-message">
        This claim shows signs of rapid spread and potential misinformation.
        Please review the analysis carefully before sharing.
      </div>
      <div class="friction-card-stats">
        <div class="friction-mini-stat">
          <span class="friction-mini-label">Cooldown Score</span>
          <span class="friction-mini-value">${Math.round((cooldown.cooldown_score || 0) * 100)}%</span>
        </div>
        <div class="friction-mini-stat">
          <span class="friction-mini-label">Velocity</span>
          <span class="friction-mini-value">${Math.round((cooldown.breakdown?.components?.velocity?.value || 0) * 100)}%</span>
        </div>
      </div>
      <div class="friction-card-countdown">
        <div class="friction-countdown-bar">
          <div class="friction-countdown-fill" id="friction-countdown-fill"></div>
        </div>
        <div class="friction-countdown-text">
          Please wait <span id="friction-countdown-seconds">5</span> seconds...
        </div>
      </div>
      <button class="friction-card-btn friction-btn-disabled" id="friction-card-continue" disabled>
        View Analysis
      </button>
    </div>
  `;
  
  row.appendChild(avatar);
  row.appendChild(card);
  chatContainer.appendChild(row);
  scrollBottom();
  
  let secondsLeft = cooldown.delay_seconds || 5;
  const secondsEl = document.getElementById("friction-countdown-seconds");
  const fillEl = document.getElementById("friction-countdown-fill");
  const continueBtn = document.getElementById("friction-card-continue");
  
  const timer = setInterval(() => {
    secondsLeft--;
    secondsEl.textContent = secondsLeft;
    
    const progress = ((cooldown.delay_seconds - secondsLeft) / cooldown.delay_seconds) * 100;
    fillEl.style.width = `${progress}%`;
    
    if (secondsLeft <= 0) {
      clearInterval(timer);
      continueBtn.disabled = false;
      continueBtn.classList.remove("friction-btn-disabled");
      continueBtn.classList.add("friction-btn-enabled");
      continueBtn.textContent = "Continue to Analysis";
    }
  }, 1000);
  
  continueBtn.addEventListener("click", () => {
    clearInterval(timer);
    trackFrictionEvent("high_concern_completed", cooldown);
    row.remove();
    onComplete();
  });
}

function showCautionBanner(data, cooldown) {
  const banner = document.createElement("div");
  banner.className = "friction-banner caution";
  banner.innerHTML = `
    <span class="material-symbols-outlined friction-banner-icon">info</span>
    <div class="friction-banner-content">
      <div class="friction-banner-title">Caution: Verify Before Sharing</div>
      <div class="friction-banner-text">
        This content shows moderate risk signals. Review the analysis below.
      </div>
    </div>
    <button class="friction-banner-close" id="friction-banner-close">
      <span class="material-symbols-outlined">close</span>
    </button>
  `;
  
  chatContainer.appendChild(banner);
  scrollBottom();
  
  document.getElementById("friction-banner-close").addEventListener("click", () => {
    trackFrictionEvent("caution_dismissed", cooldown);
    banner.remove();
  });
  
  trackFrictionEvent("caution_shown", cooldown);
}

function trackFrictionEvent(eventType, cooldown) {
  try {
    chrome.storage.local.get("frictionAnalytics", d => {
      const analytics = d.frictionAnalytics || [];
      analytics.push({
        event: eventType,
        cooldown_level: cooldown.cooldown_level,
        cooldown_score: cooldown.cooldown_score,
        timestamp: Date.now()
      });
      chrome.storage.local.set({ frictionAnalytics: analytics.slice(-100) });
    });
  } catch (e) {
    console.warn("Failed to track friction event:", e);
  }
}

// ── Internal fact card renderer ───────────────────────────────

function _renderFactCard(data, scroll = true, animate = true) {
  const verdict  = (data.verdict || "uncertain").toLowerCase();
  const confPct  = Math.round((data.confidence || 0) * 100);
  const mlPct    = Math.round((data.ml_score   || 0) * 100);
  const aiPct    = Math.round((data.ai_score   || 0) * 100);
  const newsPct  = data.evidence_score != null
    ? Math.round(data.evidence_score * 100)
    : (data.evidence_articles?.length || data.evidence?.length) ? 60 : 0;

  const srcCount = data.evidence_articles?.length || data.evidence?.length || 0;

  // ── Viral/Trending badges (Phase 2) ───────────────────────────
  const velocity = data.velocity_metrics || {};
  const isViral = velocity.is_viral || false;
  const isTrending = velocity.is_trending || false;
  let viralBadgeHtml = "";
  
  if (isViral) {
    viralBadgeHtml = `
      <div class="viral-alert-badge">
        <span class="material-symbols-outlined ms-12">warning</span>
        🚨 VIRAL ALERT - ${velocity.count_5min || 0} checks in 5 min
      </div>`;
  } else if (isTrending) {
    viralBadgeHtml = `
      <div class="trending-badge">
        <span class="material-symbols-outlined ms-12">trending_up</span>
        ⚠️ TRENDING - ${velocity.count_1hr || 0} checks in 1 hour
      </div>`;
  }

  const vClass    = verdict === "real" ? "v-real" : verdict === "fake" ? "v-fake" : "v-uncertain";
  const vIcon     = verdict === "real" ? "check_circle" : verdict === "fake" ? "cancel" : "help";
  const vLabel    = verdict === "real" ? "REAL" : verdict === "fake" ? "FAKE" : "UNCERTAIN";
  const confColor = verdict === "real" ? "var(--real)" : verdict === "fake" ? "var(--fake)" : "var(--warn)";
  const mlFill    = mlPct > 50 ? "fill-fake" : "fill-real";
  const newsFill  = newsPct > 50 ? "fill-real" : "fill-fake";

  const evidenceArticles = ensureArray(data.evidence_articles);
  const evidenceUrls = ensureArray(data.evidence);
  const hasArticles = evidenceArticles.length;
  const hasUrls     = evidenceUrls.length;

  let srcHtml = "";
  if (hasArticles) {
    srcHtml = evidenceArticles.slice(0, 4).map(a => {
      const cred = getCredTag(a.url || "");
      return `<a href="${esc(a.url)}" target="_blank">
        <div class="src-name-row">
          <span class="src-name">${esc(a.source)}</span>
          <span class="src-cred ${cred.cls}">${cred.label}</span>
        </div>
        <span class="src-title">${esc(a.title)}</span>
      </a>`;
    }).join("");
  } else if (hasUrls) {
    srcHtml = evidenceUrls.slice(0, 4).map(s => {
      const cred = getCredTag(s);
      let domain = s;
      try { domain = new URL(s).hostname.replace(/^www\./, ""); } catch {}
      return `<a href="${esc(s)}" target="_blank">
        <div class="src-name-row">
          <span class="src-name">${esc(domain)}</span>
          <span class="src-cred ${cred.cls}">${cred.label}</span>
        </div>
      </a>`;
    }).join("");
  }

  // Sub-claims extracted from long input
  let subClaimsHtml = "";
  if (data.sub_claims?.length > 1) {
    const items = data.sub_claims.map((c, i) =>
      `<div class="subclaim-item"><span class="subclaim-num">${i + 1}</span>${esc(c)}</div>`
    ).join("");
    subClaimsHtml = `
      <div class="subclaims-section">
        <div class="src-label">
          <span class="material-symbols-outlined ms-12">format_list_bulleted</span>
          Extracted claims
        </div>
        ${items}
        <div class="subclaim-note">Verdict based on: "${esc(data.primary_claim)}"</div>
      </div>`;
  }

  // Highlighted suspicious phrases
  let highlightHtml = "";
  if (data.highlights?.length) {
    const tags = data.highlights.map(h => {
      const cls = h.score >= 0.75 ? "hl-high" : h.score >= 0.5 ? "hl-med" : "hl-low";
      const tip = h.reason === "sensational" ? "Sensational language"
                : h.reason === "emotional"   ? "Emotional language"
                : h.reason === "absolute_claim" ? "Absolute claim"
                : "ML signal";
      return `<span class="hl-tag ${cls}" title="${tip}">${esc(h.phrase)}</span>`;
    }).join("");
    highlightHtml = `
      <div class="highlights-section">
        <div class="src-label">
          <span class="material-symbols-outlined ms-12">flag</span>
          Suspicious phrases
        </div>
        <div class="hl-tags">${tags}</div>
      </div>`;
  }

  const explHtml = data.explanation
    ? `<div class="fact-expl">${esc(data.explanation)}</div>` : "";

  // Manipulation badge
  let manipHtml = "";
  if (data.manipulation_score > 0.15 && data.manipulation_signals?.length) {
    const level = data.manipulation_score >= 0.5 ? "HIGH" : "MED";
    const cls   = data.manipulation_score >= 0.5 ? "manip-high" : "manip-med";
    const tags  = data.manipulation_signals.slice(0, 3).join(" · ");
    manipHtml = `
      <div class="manip-badge ${cls}">
        <span class="material-symbols-outlined ms-12">warning</span>
        Manipulation signals (${level}): ${esc(tags)}
      </div>`;
  }

  // Contradiction meter
  const ss = data.stance_summary;
  let stanceHtml = "";
  if (ss && (ss.support + ss.contradict + ss.neutral) > 0) {
    const total = ss.support + ss.contradict + ss.neutral;
    const supPct  = Math.round((ss.support    / total) * 100);
    const conPct  = Math.round((ss.contradict / total) * 100);
    const neuPct  = 100 - supPct - conPct;
    const meterLabel = ss.contradict > ss.support
      ? "⚠️ Sources conflict"
      : ss.support > 0
        ? "✓ Sources agree"
        : "Sources neutral";
    stanceHtml = `
      <div class="stance-meter">
        <div class="stance-label">${meterLabel}</div>
        <div class="stance-bar">
          <div class="stance-seg stance-sup" style="width:${supPct}%" title="Support: ${ss.support}"></div>
          <div class="stance-seg stance-neu" style="width:${neuPct}%" title="Neutral: ${ss.neutral}"></div>
          <div class="stance-seg stance-con" style="width:${conPct}%" title="Contradict: ${ss.contradict}"></div>
        </div>
        <div class="stance-counts">
          <span class="stance-sup-txt">${ss.support} support</span>
          <span class="stance-neu-txt">${ss.neutral} neutral</span>
          <span class="stance-con-txt">${ss.contradict} conflict</span>
        </div>
      </div>`;
  }

  const srcSection = srcHtml
    ? `<div class="fact-sources">
        <div class="src-label">
          <span class="material-symbols-outlined ms-12">newspaper</span>
          News Evidence
        </div>
        ${srcHtml}
      </div>` : "";

  const moderation = data.moderation_summary || null;
  let moderationHtml = "";
  if (moderation) {
    const riskPct = Math.round((moderation.risk || 0) * 100);
    const rec = (moderation.recommendation || "allow").toLowerCase();
    const recLabel = rec === "review" ? "REVIEW" : "ALLOW";
    const recCls = rec === "review" ? "mod-review" : "mod-allow";
    const flags = ensureArray(moderation.flags).slice(0, 3).join(" · ");
    moderationHtml = `
      <div class="mod-summary ${recCls}">
        <div class="mod-row">
          <span class="material-symbols-outlined ms-12">policy</span>
          <span class="mod-label">Moderation: ${recLabel}</span>
          <span class="mod-risk">${riskPct}%</span>
        </div>
        <div class="mod-risk-bar"><div class="mod-risk-fill" style="width:${riskPct}%"></div></div>
        ${flags ? `<div class="mod-flags">${esc(flags)}</div>` : ""}
      </div>`;
  }

  const row = document.createElement("div");
  row.className = "bot-row";

  const avatar = document.createElement("div");
  avatar.className = "bot-avatar";
  avatar.innerHTML = `<span class="material-symbols-outlined">fact_check</span>`;

  const card = document.createElement("div");
  card.className = "fact-card";
  card.innerHTML = `
    ${viralBadgeHtml}
    <div class="fact-verdict-hero">
      <div class="verdict-main">
        <span class="material-symbols-outlined verdict-icon-lg ${vClass}">${vIcon}</span>
        <span class="verdict-word ${vClass}">${vLabel}</span>
      </div>
      <div class="verdict-conf-row">
        <span class="verdict-conf-pct">${confPct}%</span>
        <span class="verdict-conf-label">confidence</span>
        <div class="verdict-conf-bar">
          <div class="verdict-conf-fill conf-bar" style="background:${confColor}"></div>
        </div>
      </div>
      <div class="verdict-meta">
        <span class="material-symbols-outlined ms-12">database</span>
        Analyzed from ${srcCount} source${srcCount !== 1 ? "s" : ""} · Bias checked · ML + AI + News
      </div>
      ${verdict === "uncertain" ? `<div class="uncertain-note">Signals conflict or evidence is insufficient for a definitive verdict.</div>` : ""}
      ${data.verdict_changed ? `<div class="verdict-changed-note">⚠️ This claim's verdict has changed since it was last checked.</div>` : ""}
    </div>
    <div class="fact-body">
      <div class="score-row">
        <span class="score-lbl">ML</span>
        <div class="score-track"><div class="score-fill ${mlFill} ml-bar"></div></div>
        <span class="score-num">${mlPct}%</span>
      </div>
      <div class="score-row">
        <span class="score-lbl">AI</span>
        <div class="score-track"><div class="score-fill fill-ai ai-bar"></div></div>
        <span class="score-num">${aiPct}%</span>
      </div>
      <div class="score-row">
        <span class="score-lbl">News</span>
        <div class="score-track"><div class="score-fill ${newsFill} news-bar"></div></div>
        <span class="score-num">${newsPct}%</span>
      </div>
      ${moderationHtml}
      ${manipHtml}
      ${subClaimsHtml}
      ${highlightHtml}
      ${explHtml}
      ${stanceHtml}
      ${srcSection}
      <div class="fact-actions">
        <button class="fact-btn view-btn">View Detail</button>
        <button class="fact-btn primary save-btn">Save Claim</button>
        <button class="fact-btn feedback-btn" title="Report wrong verdict">⚑ Wrong?</button>
      </div>
    </div>`;

  row.appendChild(avatar);
  row.appendChild(card);
  chatContainer.appendChild(row);

  card.querySelector(".ml-bar").style.width    = `${mlPct}%`;
  card.querySelector(".ai-bar").style.width    = `${aiPct}%`;
  card.querySelector(".news-bar").style.width  = `${newsPct}%`;
  card.querySelector(".conf-bar").style.width  = `${confPct}%`;
  card.querySelector(".view-btn").addEventListener("click", () => viewDetail(data));
  card.querySelector(".save-btn").addEventListener("click", e => saveCard(data, e.currentTarget));
  card.querySelector(".feedback-btn").addEventListener("click", () => showFeedback(card, data));

  // Typewriter effect on explanation (only for new messages)
  const explEl = card.querySelector(".fact-expl");
  if (explEl && data.explanation && animate) {
    const full = data.explanation;
    explEl.textContent = "";
    let i = 0;
    const tw = setInterval(() => {
      explEl.textContent += full[i];
      i++;
      if (i >= full.length) clearInterval(tw);
      scrollBottom();
    }, 12);
  }

  if (scroll) scrollBottom();
}


function viewDetail(data) {
  chrome.storage.local.set({ detailData: data }, () => { window.location.href = chrome.runtime.getURL("popup/detail.html"); });
}

function saveCard(data, btn) {
  chrome.storage.local.get("savedClaims", d => {
    const claims = d.savedClaims || [];
    const key = data.content || data.explanation || "";
    if (claims.some(c => (c.content || c.explanation || "") === key)) {
      if (btn) { btn.textContent = "Already saved"; btn.disabled = true; }
      return;
    }
    claims.unshift(data);
    chrome.storage.local.set({ savedClaims: claims.slice(0, 50) });
    if (btn) {
      btn.textContent = "Saved ✓";
      btn.style.background = "var(--real)";
      btn.style.color = "#fff";
      btn.disabled = true;
    }
  });
}

function showFeedback(card, data) {
  // Replace actions row with inline correction picker
  const actionsEl = card.querySelector(".fact-actions");
  actionsEl.innerHTML = `
    <span class="feedback-prompt">Correct verdict:</span>
    <button class="fact-btn feedback-real">✓ Real</button>
    <button class="fact-btn feedback-fake">✗ Fake</button>
    <button class="fact-btn feedback-cancel">Cancel</button>`;
  actionsEl.querySelector(".feedback-real").addEventListener("click", () => submitFeedback(card, data, "real"));
  actionsEl.querySelector(".feedback-fake").addEventListener("click", () => submitFeedback(card, data, "fake"));
  actionsEl.querySelector(".feedback-cancel").addEventListener("click", () => {
    actionsEl.innerHTML = `
      <button class="fact-btn view-btn">View Detail</button>
      <button class="fact-btn primary save-btn">Save Claim</button>
      <button class="fact-btn feedback-btn" title="Report wrong verdict">⚑ Wrong?</button>`;
    actionsEl.querySelector(".view-btn").addEventListener("click", () => viewDetail(data));
    actionsEl.querySelector(".save-btn").addEventListener("click", () => saveCard(data));
    actionsEl.querySelector(".feedback-btn").addEventListener("click", () => showFeedback(card, data));
  });
}

async function submitFeedback(card, data, actual) {
  const actionsEl = card.querySelector(".fact-actions");
  actionsEl.innerHTML = `<span class="feedback-prompt" style="color:var(--real)">✓ Feedback recorded</span>`;
  try {
    await authFetch("/feedback", {
      method: "POST",
      body: JSON.stringify({
        claim_text: feedbackClaimText(data),
        predicted:  data.verdict || "uncertain",
        actual,
        confidence: data.confidence || null,
      })
    });
  } catch(_) {}
}

// ── Attach menu ───────────────────────────────────────────────
let attachedImageUrl  = null;  // base64 data URI for images
let attachedFileData  = null;  // { file, type } or { text, type }
let attachedFileName  = null;

const attachBtn  = document.getElementById("attach-btn");
const attachMenu = document.getElementById("attach-menu");

attachBtn.addEventListener("click", e => {
  e.stopPropagation();
  attachMenu.style.display = attachMenu.style.display === "none" ? "block" : "none";
});
document.addEventListener("click", () => { attachMenu.style.display = "none"; });

function _showPreview(icon, name) {
  document.getElementById("attach-preview-icon").textContent = icon;
  document.getElementById("attach-preview-name").textContent = name;
  document.getElementById("attach-preview-bar").style.display = "flex";
  attachMenu.style.display = "none";
}

function _clearAttach() {
  attachedImageUrl  = null;
  attachedFileData  = null;
  attachedFileName  = null;
  document.getElementById("attach-preview-bar").style.display = "none";
  ["file-image","file-audio","file-pdf","file-txt"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = "";
  });
}

document.getElementById("attach-remove-btn").addEventListener("click", _clearAttach);

// Image — compress to JPEG max 800px before sending to avoid 413
document.getElementById("file-image").addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file) return;
  const img = new Image();
  const objectUrl = URL.createObjectURL(file);
  img.onload = () => {
    URL.revokeObjectURL(objectUrl);
    const MAX = 800;
    let w = img.width, h = img.height;
    if (w > MAX || h > MAX) {
      const ratio = Math.min(MAX / w, MAX / h);
      w = Math.round(w * ratio);
      h = Math.round(h * ratio);
    }
    const canvas = document.createElement("canvas");
    canvas.width = w; canvas.height = h;
    canvas.getContext("2d").drawImage(img, 0, 0, w, h);
    // Compress to JPEG at 0.6 quality — keeps base64 under 300KB for most images
    attachedImageUrl = canvas.toDataURL("image/jpeg", 0.6);
    attachedFileName = file.name;
    _showPreview("image", `${file.name} (compressed)`);
  };
  img.src = objectUrl;
});

// Audio — store file, send to /upload on submit (server-side Whisper transcription)
document.getElementById("file-audio").addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file) return;
  const sizeMB = file.size / (1024 * 1024);
  if (sizeMB > 25) {
    alert(`Audio file too large: ${sizeMB.toFixed(1)}MB (max 25MB)`);
    e.target.value = "";
    return;
  }
  attachedFileData = { file, type: "audio" };
  attachedFileName = file.name;
  _showPreview("audiotrack", `${file.name} (${sizeMB.toFixed(1)}MB)`);
});


// PDF — store file, send to /upload on submit (server-side pdfplumber extraction)
document.getElementById("file-pdf").addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file) return;
  const sizeMB = file.size / (1024 * 1024);
  if (sizeMB > 20) {
    alert(`PDF too large: ${sizeMB.toFixed(1)}MB (max 20MB)`);
    e.target.value = "";
    return;
  }
  attachedFileData = { file, type: "pdf" };
  attachedFileName = file.name;
  _showPreview("picture_as_pdf", file.name);
});

// TXT / DOCX — plain text read client-side; DOCX sent to /upload server-side
document.getElementById("file-txt").addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file) return;
  const sizeMB = file.size / (1024 * 1024);
  if (sizeMB > 20) {
    alert(`File too large: ${sizeMB.toFixed(1)}MB (max 20MB)`);
    e.target.value = "";
    return;
  }
  // DOCX/DOC are binary — send to /upload for server-side extraction
  if (/\.(docx?)$/i.test(file.name)) {
    attachedFileData = { file, type: "docx" };
    attachedFileName = file.name;
    _showPreview("description", file.name);
    return;
  }
  // Plain text — read client-side (safe, no binary garbage)
  const reader = new FileReader();
  reader.onload = ev => {
    const text = ev.target.result.slice(0, 3000);
    // Store as attachment — do NOT dump into input box
    attachedFileData = { text, type: "txt" };
    attachedFileName = file.name;
    _showPreview("description", file.name);
  };
  reader.readAsText(file);
});
let _sending = false;  // guard against duplicate in-flight requests

async function send() {
  if (_sending) return;                    // prevent duplicate requests
  const text = inputText.value.trim();
  if (!text && !attachedImageUrl && !attachedFileData) return;
  _sending = true;
  inputText.value = "";
  autoResize();

  if (chatContainer.querySelector(".welcome-screen")) {
    chatContainer.innerHTML = "";
  }

  // Capture and clear attachments before async
  const imageUrl = attachedImageUrl;
  const fileData = attachedFileData;
  const fileName = attachedFileName;
  _clearAttach();

  // If image attached with no/short message, use a descriptive prompt
  let sendText = text;
  if (imageUrl && text.length < 10) {
    sendText = text.length > 0 ? text : "What does this image show? Is there any misinformation or fake news in it?";
  }
  if (!sendText && !fileData) sendText = "Analyze this content";

  // Show user message (with file name badge if file attached)
  addUserMsg(text || (fileName ? "\uD83D\uDCCE " + fileName : ""), true, imageUrl);
  const typing = addTyping();
  sendBtn.disabled = true;

  try {
    let res, data;

    // ── File upload path (PDF / DOCX / audio / txt) ───────────
    if (fileData) {
      const form = new FormData();
      if (fileData.file) {
        form.append("file", fileData.file, fileData.file.name);
      } else if (fileData.text) {
        // Plain text — wrap in Blob so /upload receives it as a file
        const blob = new Blob([fileData.text], { type: "text/plain" });
        form.append("file", blob, fileName || "document.txt");
      }
      if (sendText) form.append("claim", sendText);
      form.append("language", "en");
      // uploadFetch — no Content-Type header (browser sets multipart boundary)
      res  = await uploadFetch("/upload", form);
      data = await readJsonSafe(res);

    // ── Image path — send to /message with image_url ──────────
    } else if (imageUrl) {
      const body = { message: sendText, session_id: currentSessionId, history };
      body.image_url = imageUrl;
      res  = await authFetch("/message", { method: "POST", body: JSON.stringify(body) });
      data = await readJsonSafe(res);

    // ── Normal text path ──────────────────────────────────────
    } else {
      const body = { message: sendText, session_id: currentSessionId, history };
      res  = await authFetch("/message", { method: "POST", body: JSON.stringify(body) });
      data = await readJsonSafe(res);
    }

    if (!res.ok) {
      let detail = `Server error ${res.status}`;
      if (data) {
        if (typeof data.detail === "string") detail = data.detail;
        else if (Array.isArray(data.detail)) detail = data.detail.map(e => e.msg || JSON.stringify(e)).join("; ");
        else if (typeof data.message === "string") detail = data.message;
      }
      throw new Error(detail);
    }
    typing.remove();

    if (data.session_id && data.session_id !== currentSessionId) {
      currentSessionId = data.session_id;
      chrome.storage.local.set({ currentSessionId });
      await loadSessions();
    }

    const normalized = normalizeMessageResponse(data || {});
    if (normalized.is_claim) {
      addFactCard(normalized);
    } else {
      addChatReply(normalized.reply || "");
      history.push({ role: "user", content: text });
      history.push({ role: "assistant", content: normalized.reply || "" });
      if (history.length > 20) history = history.slice(-20);
    }

    if (currentSessionId) {
      const s = sessions.find(x => x.id === currentSessionId);
      if (s) {
        // For file uploads, show filename as title instead of PDF content
        const displayTitle = fileName
          ? fileName.replace(/\.[^.]+$/, "")  // strip extension
          : s.title;
        setChatTitle(displayTitle);
      }
    }
  } catch(err) {
    typing.remove();
    addChatReply(`Connection error: ${err.message}. Make sure the backend is running.`);
  } finally {
    sendBtn.disabled = false;
    _sending = false;
  }
}

// Helper — set the header title, preserving TruvantaAI brand styling
function setChatTitle(title) {
  const el = document.getElementById("chat-title");
  if (!el) return;
  if (!title || title === "TruvantaAI") {
    el.innerHTML = '<span class="brand-main">Truvanta</span><span class="brand-ai">AI</span>';
  } else {
    // Session title — plain text, no brand styling
    el.textContent = title;
  }
}

async function authFetch(path, opts = {}) {
  const res = await apiFetch(path, {
    ...opts,
    headers: buildHeaders({
      "Content-Type": "application/json",
      ...(token ? { "Authorization": `Bearer ${token}` } : {}),
      ...(opts.headers || {}),
    })
  });
  if (res.status === 401) {
    chrome.storage.local.clear(() => { window.location.href = chrome.runtime.getURL("popup/login.html"); });
  }
  return res;
}

// uploadFetch — multipart/form-data (NO Content-Type; browser sets boundary automatically)
async function uploadFetch(path, formData) {
  const headers = {};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await apiFetch(path, { method: "POST", headers, body: formData });
  if (res.status === 401) {
    chrome.storage.local.clear(() => { window.location.href = chrome.runtime.getURL("popup/login.html"); });
  }
  return res;
}

function autoResize() {
  inputText.style.height = "auto";
  inputText.style.height = Math.min(inputText.scrollHeight, 88) + "px";
}


// ── WebSocket Status Indicator ────────────────────────────────
function updateWSStatus() {
  const statusEl = document.getElementById('ws-status');
  if (!statusEl) return;
  
  const state = wsManager.getState();
  const textEl = statusEl.querySelector('.ws-status-text');
  
  // Remove all state classes
  statusEl.classList.remove('connected', 'connecting', 'reconnecting', 'disconnected');
  
  // Add current state class
  statusEl.classList.add(state);
  
  // Update text
  switch (state) {
    case 'connected':
      textEl.textContent = 'Live';
      statusEl.classList.add('visible');
      // Hide after 2 seconds when connected
      setTimeout(() => {
        if (wsManager.getState() === 'connected') {
          statusEl.classList.remove('visible');
        }
      }, 2000);
      break;
    case 'connecting':
      textEl.textContent = 'Connecting...';
      statusEl.classList.add('visible');
      break;
    case 'reconnecting':
      textEl.textContent = 'Reconnecting...';
      statusEl.classList.add('visible');
      break;
    case 'disconnected':
      textEl.textContent = 'Offline';
      statusEl.classList.add('visible');
      break;
  }
}

// Register WebSocket state change handler
if (typeof wsManager !== 'undefined') {
  wsManager.onStateChange(updateWSStatus);
  
  // Initial status update
  setTimeout(updateWSStatus, 100);
  
  // Register custom message handlers
  wsManager.on('claim_verified', (message) => {
    console.log('[Popup] Claim verified notification:', message);
    // Could show a toast notification here
  });
  
  wsManager.on('review_queue_update', (message) => {
    console.log('[Popup] Review queue updated:', message);
    // Reload review queue if on review page
  });
}

// ── Voice Recording ───────────────────────────────────────────
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;

// Initialize voice button after DOM is loaded
function initVoiceButton() {
  const voiceBtn = document.getElementById("voice-btn");
  if (!voiceBtn) {
    console.warn("Voice button not found - will retry");
    return;
  }
  voiceBtn.addEventListener("click", toggleVoiceRecording);
  console.log("Voice button initialized");
}

async function toggleVoiceRecording() {
  if (isRecording) {
    stopVoiceRecording();
    return;
  }
  
  await startVoiceRecording();
}

async function checkMicrophonePermission() {
  // This function is no longer needed - we'll request permission directly
  return true;
}

async function startVoiceRecording() {
  const voiceBtn = document.getElementById("voice-btn");
  if (!voiceBtn) return;
  
  try {
    // Use browser's built-in speech recognition (FREE!)
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      // Use Web Speech API (free, no backend needed)
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      
      let finalTranscript = '';
      
      recognition.onstart = () => {
        isRecording = true;
        voiceBtn.querySelector('.material-symbols-outlined').textContent = 'graphic_eq';
        voiceBtn.style.color = '#f5576c';
        voiceBtn.style.animation = 'pulse 1.5s ease-in-out infinite';
        voiceBtn.title = 'Stop recording';
        inputText.placeholder = '🎤 Listening...';
        inputText.style.borderColor = '#f5576c';
        inputText.style.boxShadow = '0 0 0 3px rgba(245, 87, 108, 0.1)';
      };
      
      recognition.onresult = (event) => {
        let interimTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }
        
        // Show live transcription
        inputText.value = (finalTranscript + interimTranscript).trim();
        autoResize();
      };
      
      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        resetVoiceUI();
        
        let msg = 'Speech recognition error.\n\n';
        if (event.error === 'not-allowed') {
          msg += 'Microphone access denied.\n\nPlease:\n1. Click 🔒 in address bar\n2. Allow microphone\n3. Try again';
        } else if (event.error === 'no-speech') {
          msg = 'No speech detected. Please try again.';
        } else {
          msg += event.error;
        }
        
        alert(msg);
      };
      
      recognition.onend = () => {
        isRecording = false;
        resetVoiceUI();
        
        const text = finalTranscript.trim();
        if (text) {
          inputText.value = text;
          autoResize();
          
          // Smart claim detection
          if (detectClaimIntent(text)) {
            setTimeout(() => send(), 500);
          } else {
            inputText.focus();
          }
        }
      };
      
      mediaRecorder = recognition; // Store for stopping
      recognition.start();
      
    } else {
      // Fallback: Record audio and use backend
      await startAudioRecording();
    }
    
  } catch (error) {
    console.error('Recording failed:', error);
    resetVoiceUI();
    alert('Failed to start recording: ' + error.message);
  }
}

async function startAudioRecording() {
  // Fallback method using MediaRecorder
  const voiceBtn = document.getElementById("voice-btn");
  
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  
  const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4';
  mediaRecorder = new MediaRecorder(stream, { mimeType });
  audioChunks = [];
  
  mediaRecorder.ondataavailable = (event) => {
    if (event.data.size > 0) audioChunks.push(event.data);
  };
  
  mediaRecorder.onstop = async () => {
    stream.getTracks().forEach(track => track.stop());
    await processVoiceRecording();
  };
  
  mediaRecorder.start(100);
  isRecording = true;
  
  voiceBtn.querySelector('.material-symbols-outlined').textContent = 'graphic_eq';
  voiceBtn.style.color = '#f5576c';
  voiceBtn.style.animation = 'pulse 1.5s ease-in-out infinite';
  voiceBtn.title = 'Stop recording';
  inputText.placeholder = '🎤 Listening...';
  inputText.style.borderColor = '#f5576c';
  inputText.style.boxShadow = '0 0 0 3px rgba(245, 87, 108, 0.1)';
}

function detectClaimIntent(text) {
  // Client-side claim detection
  const textLower = text.toLowerCase().trim();
  
  // Questions are usually chat
  const questionStarters = ['what is', 'what are', 'who is', 'when did', 'where is', 'why did', 'how does', 'can you', 'tell me', 'explain'];
  if (questionStarters.some(q => textLower.startsWith(q))) return false;
  
  // Greetings are chat
  const greetings = ['hello', 'hi ', 'hey ', 'thanks'];
  if (greetings.some(g => textLower.startsWith(g))) return false;
  
  // Claim indicators
  const hasFactualVerb = /\b(is|are|was|were|will be|has been|contains?)\b/.test(textLower);
  const hasNumbers = /\d+\s*(percent|%|million|billion|thousand|people)/.test(textLower);
  const hasAbsolutes = /\b(always|never|all|none|every|everyone)\b/.test(textLower);
  const hasCausation = /\b(causes?|leads? to|results? in|due to|makes?)\b/.test(textLower);
  const hasAuthority = /\b(study|research|scientists?|doctors?|experts?|government)\b/.test(textLower);
  const hasControversial = /\b(vaccine|covid|election|climate|conspiracy|hoax|fake)\b/.test(textLower);
  
  const score = (hasFactualVerb ? 2 : 0) + (hasNumbers ? 1 : 0) + (hasAbsolutes ? 1 : 0) + 
                (hasCausation ? 1 : 0) + (hasAuthority ? 1 : 0) + (hasControversial ? 2 : 0);
  
  return score >= 2;
}

function resetVoiceUI() {
  const voiceBtn = document.getElementById("voice-btn");
  if (voiceBtn) {
    voiceBtn.querySelector('.material-symbols-outlined').textContent = 'mic';
    voiceBtn.style.color = '';
    voiceBtn.style.animation = '';
    voiceBtn.title = 'Voice input';
  }
  inputText.placeholder = 'Ask anything or paste a claim…';
  inputText.style.borderColor = '';
  inputText.style.boxShadow = '';
  isRecording = false;
}

function stopVoiceRecording() {
  if (!mediaRecorder) return;
  
  isRecording = false;
  
  // Check if it's Web Speech API or MediaRecorder
  if (mediaRecorder.stop) {
    mediaRecorder.stop();
  }
  
  resetVoiceUI();
}

async function processVoiceRecording() {
  try {
    const audioBlob = new Blob(audioChunks, { type: mediaRecorder.mimeType });
    
    // Validate size
    const sizeMB = audioBlob.size / (1024 * 1024);
    if (sizeMB > 25) {
      throw new Error('Recording too large (max 25MB)');
    }
    
    if (audioBlob.size < 1024) {
      throw new Error('Recording too short. Please speak for at least 1 second.');
    }
    
    // Show processing message
    inputText.placeholder = 'Transcribing audio...';
    
    // Transcribe audio with smart claim detection
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');
    formData.append('language', 'en');
    formData.append('auto_detect_claim', 'true');
    
    const response = await authFetch('/audio/transcribe', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      let errorMsg = 'Transcription failed';
      try {
        const error = await response.json();
        errorMsg = error?.detail || errorMsg;
      } catch (e) {
        errorMsg = `Server error: ${response.status}`;
      }
      throw new Error(errorMsg);
    }
    
    const result = await response.json();
    
    if (!result.success || !result.text) {
      throw new Error('No transcription received. Please try again.');
    }
    
    // Put transcribed text in input
    inputText.value = result.text;
    inputText.placeholder = 'Ask anything or paste a claim…';
    autoResize();
    
    // Auto-send if backend detected it as a claim
    if (result.claim_detected) {
      // Backend detected this as a factual claim - auto-verify
      setTimeout(() => send(), 500);
    } else {
      // Looks like a question/chat - let user review
      inputText.focus();
    }
    
  } catch (error) {
    console.error('Processing error:', error);
    resetVoiceUI();
    
    let msg = 'Failed to transcribe audio.\n\n';
    if (error.message) {
      msg += error.message;
    } else {
      msg += 'Please check:\n- Backend is running\n- OpenAI API key is set\n- Internet connection';
    }
    
    alert(msg);
  }
}
